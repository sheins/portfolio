<?php get_header(); ?>

    <div class="container" role="main">

	    <div class="row">

	    	<div class="col-md-8">

			    <div class="page-header">	
			    	<h1><?php wp_title( '' ); ?></h1>
			    </div>

			    <p>Offer some really helpful advice here</p>

				</article>				

	    	</div>	    

	    </div>

    </div>

<?php get_footer(); ?>